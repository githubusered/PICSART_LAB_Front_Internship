# Frontend-Internship
Landing Page

# Install

Live Sass Compiler extension


# For running

1. Click Watch Sass
2. Go Live or live-server

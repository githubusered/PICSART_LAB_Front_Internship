import React from 'react';
import './Form.css'
import { Formik,Form,Field,ErrorMessage} from 'formik';
import * as yup from 'yup';


const rgxForPassword = /^(?=.*\d)(?=.*[!@#$%^&*])(?=.*[a-z])(?=.*[A-Z]).{8,}$/;
const rgxForFirstAndLastname = /^[\w'\-,.][^0-9_!¡?÷?¿/\\+=@#$%ˆ&*(){}|~<>;:[\]]{2,}$/;
const rgxForEmail = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i;

const initialValues = {
    firstname:'',
    lastname:'',
    numbername:'',
    email:'',
    password: '',
    checked:false,
}

const onSubmit =  (values,onSubmitProps) => {
    console.log("Form data1111",onSubmitProps)
    onSubmitProps.setSubmitting(false)
    onSubmitProps.resetForm()
}

const validationSchema = yup.object({
    firstname: yup
        .string()
        .required('Required')
        .matches(rgxForFirstAndLastname,'Invalid firstname')
    ,
    lastname: yup
        .string()
        .required('Required')
        .matches(rgxForFirstAndLastname,'Invalid lastname')
    ,
    email: yup
        .string()
        .required('Required')
        .matches(rgxForEmail,'Invalid email format')
    ,
    password: yup
        .string()
        .required('Required')
        .matches(rgxForPassword,'Invalid password format')
});

function RegisterForm() {
    
    return (
        <Formik 
            initialValues={initialValues}
            onSubmit={onSubmit}
            validationSchema={validationSchema}
        >
            {
                formik =>{
                    return (
                    <Form>
                        <h1>Create new account</h1>
                        <div className='basicInputs'>
                            <div>
                                <p>First Name</p>
                                <Field 
                                    type="text" 
                                    placeholder='First Name' 
                                    id='firstname' 
                                    name="firstname" 
                                />
                                <ErrorMessage name='firstname'  component='div' className='errors' />
                            </div>
                            <div>
                                <p>Last Name</p>
                                <Field 
                                    type="text"
                                    placeholder='Last Name'
                                    id='lastname'
                                    name="lastname" 
                                />
                                <ErrorMessage name='lastname'  component='div' className='errors'/>
                            </div>
                        </div>
                        <div className='secondaryInputs'>
                            <p>Team name/number</p>
                            <Field 
                                type="text" 
                                placeholder='Team name/number'
                                id='numbername' 
                                name="numbername"
                            />
                        </div>
                        <div className='secondaryInputs'>
                            <p>Email Address</p>
                            <Field 
                                type="email" 
                                placeholder='Email Address' 
                                id='email' 
                                name="email" 
                            />
                                <ErrorMessage name='email' component='div' className='errors'/>
                        </div>
                        <div className='secondaryInputs'>
                            <p>Password</p>
                            <Field 
                                type="password" 
                                placeholder='Create a password' 
                                id='password' 
                                name="password" 
                            />
                                <ErrorMessage name='password' component='div' className='errors'/>

                        </div>
                        <label htmlFor="terms">
                            <Field 
                                type="checkbox"
                                id='checkbox'
                                name='checked' 
                            />{console.log('f',formik)}
                            <span className={!formik.values.checked ? 'required': 'success'}>I agree to the Terms of Service and Privacy Policy.</span>
                        </label>
                        <div className='submitDIV'>
                            <button className='btn btnSIGN' type='submit' disabled={!formik.isValid || formik.isSubmitting}>SIGN UP</button>
                            <p>OR</p>
                            <button className='btn btnContinueGoogle' >
                                {/* <img src="./Images/googleLOGO.png" 
                                alt="Google_logo" 
                            /> */}
                            Continue with Google</button>
                        </div>
                    </Form>
                    )
                }
            }
        </Formik>
    )
}

export default RegisterForm;


